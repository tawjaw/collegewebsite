import {useEffect, useState} from 'react';
import ToDoItem from './ToDoItem';
import axios from 'axios';


function ToDoList() {
    

    //our state that keeps track of our list of todos
    const [todos, setTodos] = useState([]);
    const loadTodosFromAPI = ()=>{
        /* TODO
        make a get request to 
        https://todoitems-rest.herokuapp.com/users/<student_id>/todoitems
        use the data as the new value for the todos state
        */
        
    }
    const addItem = (item)=>{
        /* TODO
        make a post request to 
        https://todoitems-rest.herokuapp.com/users/<student_id>/todoitems'

        and pass the item as data to the post request

        item is an object that should contain title and description
        there are some restrictions on title and description that you should figure out by testing it
        for example, use Postman and make a post request with body data:
        {
            "title": "test",
            "description": "test"
        }

        You need to catch the error and use it to display a meaningful message to the user based on it

        after the post is successful (response has a 200 status code), load the full todoitems 
        */
    }

    
    /*
     * TODO 
     * use useEffect to load the data when the component is first created
     * do not rewrite the same code! we have a function above that you should use it
     * 
     */


    const setComplete = (id, complete)=>{
        //TODO
        /*
            id is the id of the todoitem you want to set the complete for it
            complete is a boolean True or False

            make a PUT request to 
            https://todoitems-rest.herokuapp.com/users/<student_id>/todoitems/<todo_id>

            in the data of the request pass an object that has key "complete" and
            value of the complete passed to this function

            after the PUT is successful, load the full todoitems 
        */
        
        
    }

    const deleteItem = (id)=>{
        //TODO
        /*

            make a DELETE request to 
            https://todoitems-rest.herokuapp.com/<student_id>/123/todoitems/<todo_id>

            after the request is successful, reload the full todoitems 
        */
   
    }



    return (
        <div>
        {
            /*
                TODO
                For every todo item in todos,
                render a a ToDoItem element passing to it that item object
                with the functions needed as props

                Add a form that has an input to write the new title and description
                And a submit button. 

                When the submit button is pressed
                if the text of the input is not empty, add a new item to the todo items
                
                if it is not successful, display a meaningful message to the user
            */
        }    
        
        
        </div>    )
}

export default ToDoList;
