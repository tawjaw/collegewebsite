
function ToDoItem({item, setComplete, deleteItem})
{
    //this component takes three props
    // - item object which contains _id, complete, and description
    // - setComplete function which takes an id as parameter and boolean state for the complete to be set
    // - deleteItem function which takes an id as parameter
    return(
        <>
        
        {/*
            TODO
            - Display the title of the todo item 
            - Display the description of the todo item
            - if it is complete add styling to to the text to display a line strike on the text
            - when the text is clicked, toggle the complete of this item
            - if the item is completed, display a button next to it and when this button is pressed
                delete this item from our list of todos  

        */}

        </>
    )
}

export default ToDoItem;