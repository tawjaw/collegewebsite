import './App.css';
import ToDoList from './components/ToDoList';

function App() {
  return (
    <div>
      <ToDoList></ToDoList>
    </div>
  );
}

export default App;
