import {useState} from 'react';
import ToDoItem from './ToDoItem';

let id = 4;

function ToDoList() {
    //this list of objects is used as our initial value for our state
    const initialToDoList = [
    {id: 1, description: 'do laundry', complete: false},
    {id: 2, description: 'buy groceries', complete: false},
    {id: 3, description: 'do homework', complete: false}
    ];

    //our state that keeps track of our list of todos
    const [todos, setTodos] = useState(initialToDoList);

    const toggleComplete = (id)=>{
        //TODO
        //creates a new list of todos that includes the same items
        //where the id does not match, and a modified object of todo 
        //where the id matches with the complete property toggled

        //sets the state using this new list

        /*

        You might want to look at:
        Modifying a copied object
        http://champlaincsc.com/~tjawhar/javaweb/references/threedots.html#modify-a-copied-object
        and using Map
        http://champlaincsc.com/~tjawhar/javaweb/references/functional.html#array-prototype-map
        */
    }

    const deleteItem = (id)=>{
        //TODO
        //creates a new list of todos that includes all the elements in todos
        //except the one that matches the id
        
        //sets the state using this new list
        /*

        You might want to look at:
        filter
        http://champlaincsc.com/~tjawhar/javaweb/references/functional.html#array-prototype-filter

        */
    }

    const addItem = (description)=>{
        //TODO
        //creates a new list with all the items in todos + the new item
        //with the description that is passed to the function
        //the new item will have complete to be false and id to be the global id 
        //that is being incremented at the end of this function 

        //sets the state using this new list
        /*

        You might want to look at:
        Add element to a copied array
        http://champlaincsc.com/~tjawhar/javaweb/references/threedots.html#add-element-to-a-copied-array
        */
       id++;
    }

    return (
        <div>
        {
            /*
                TODO
                For every todo item in todos,
                render a a ToDoItem element passing to it that item object
                with the functions needed as props

                Add a form that has an input to write the new description
                And a submit button. 
                When the submit button is pressed
                if the text of the input is not empty, add a new item to the todo items
                then clear the text of the input 
            */
        }    
        </div>    )
}

export default ToDoList;
